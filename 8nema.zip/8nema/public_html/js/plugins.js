/*global $*/

$(document).ready(function () {

$('.address-tab').click(function(){
$(this).toggleClass('myactive');
})

    var current_fs, next_fs, previous_fs; //fieldsets
    var opacity;
    
    $(".next").click(function(){
    
    current_fs = $(this).parent();
    next_fs = $(this).parent().next();
    
    //Add Class Active
    $("#progressbar li").eq($(".form-card").index(next_fs)).addClass("active");
    
    //show the next fieldset
    next_fs.show();
    //hide the current fieldset with style
    current_fs.animate({opacity: 0}, {
    step: function(now) {
    // for making fielset appear animation
    opacity = 1 - now;
    
    current_fs.css({
    'display': 'none',
    'position': 'relative'
    });
    next_fs.css({'opacity': opacity});
    },
    duration: 600
    });
    });
    
    $(".previous").click(function(){
    
    current_fs = $(this).parent();
    previous_fs = $(this).parent().prev();
    
    //Remove class active
    $("#progressbar li").eq($(".form-card").index(current_fs)).removeClass("active");
    
    //show the previous fieldset
    previous_fs.show();
    
    //hide the current fieldset with style
    current_fs.animate({opacity: 0}, {
    step: function(now) {
    // for making fielset appear animation
    opacity = 1 - now;
    
    current_fs.css({
    'display': 'none',
    'position': 'relative'
    });
    previous_fs.css({'opacity': opacity});
    },
    duration: 600
    });
    });
    
  
    
    $(".submit").click(function(){
    return false;
    })

    $(window).on("load", function () {
        $('body').css('overflow', 'auto');
        $('.loading-overlay').delay(2500).slideToggle("slow");;
    });


    ss = $("#scroll-up");

    $(window).scroll(function () {
        if ($(this).scrollTop() >= 400) {
            ss.show();
        } else {
            ss.hide();
        }

    });


    ss.click(function () {
        $("html,body").animate({
            scrollTop: 0
        }, 600);
    });
  
  
    $('#stars li').on('mouseover', function () {
        var onStar = parseInt($(this).data('value'), 10); // The star currently mouse on

        // Now highlight all the stars that's not after the current hovered star
        $(this).parent().children('li.star').each(function (e) {
            if (e < onStar) {
                $(this).addClass('hover');
            } else {
                $(this).removeClass('hover');
            }
        });
    }).on('mouseout', function () {
        $(this).parent().children('li.star').each(function (e) {
            $(this).removeClass('hover');
        });
    });
    $('#stars li').on('click', function () {
        onStar = parseInt($(this).data('value'), 10); // The star currently selected
        stars = $(this).parent().children('li.star');

        for (i = 0; i < stars.length; i++) {
            $(stars[i]).removeClass('selected');
        }

        for (i = 0; i < onStar; i++) {
            $(stars[i]).addClass('selected');
        }

    });

    $('.like-product').click(function(){
        $(this).toggleClass('fa-heart');
        $(this).toggleClass('fa-heart-o');
    });

    $('#product').owlCarousel({
        autoplay: true,
        rtl: true,
        loop: true,
        margin: 10,
        nav: false,
        dots: false,
        transitionStyle: true,
        autoplayTimeout: 4000,
        autoplayHoverPause: true,
        navText: false,

        thumbs: true,
        thumbsPrerendered: true,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            1000: {
                items: 4
            }
        }
    });

    'use strict';

    var onStar,
        stars,
        scrollButton,
        atr,
        i;

    scrollButton = $("#scroll-top");

    $(window).scroll(function () {
        if ($(this).scrollTop() >= 500) {
            scrollButton.show();
        } else {
            scrollButton.hide();
        }

    });

    $(window).scroll(function () {
        var scroll = $(window).scrollTop();
        if (scroll >= 700) {

            $(".distribution").removeClass("clean");
        } else {
            $(".distribution").addClass("clean");
        }
    });





 


    $("#owl-demo").owlCarousel({

        navigation: true, // Show next and prev buttons
        slideSpeed: 300,
        autoplay: true,
        paginationSpeed: 400,
        items: 1,
        dots: true,
        autoplayTimeout: 4000,
        autoplayHoverPause: true,
        nav: false,
        rtl: true,
        navText: ["<img src='img/right-img.png'>", "<img src='img/left-img.png'>"],
        loop: true

    });

    $("#owl-offers").owlCarousel({

        navigation: true, // Show next and prev buttons
        slideSpeed: 300,
        autoplay: true,
        paginationSpeed: 400,
        items: 1,
        dots: true,
        autoplayTimeout: 4000,
        autoplayHoverPause: true,
        nav: false,
        rtl: true,
        navText: ["<img src='img/right-img.png'>", "<img src='img/left-img.png'>"],
        loop: true

    });


    $('#owl-sections').owlCarousel({
        autoPlay: true, //Set AutoPlay to 3 seconds
        rtl: true,
        loop: true,
        autoplay: true,
        autoplayTimeout: 4000,
        autoplayHoverPause: true,
        dots: false,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 2
            },
            800: {
                items: 3
            },
            1000: {
                items: 4
            }
        },
        nav: false,
        navText: ["<i class='fa fa-caret-right' aria-hidden='true'></i>", "<i class='fa fa-caret-left' aria-hidden='true'></i>"],
        margin: 10
    });


    $('#owl-details').owlCarousel({
        autoPlay: true, //Set AutoPlay to 3 seconds
        rtl: true,
        loop: true,
        autoplay: true,
        dots: false,
        autoplayTimeout: 4000,
        autoplayHoverPause: true,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 2
            },
            800: {
                items: 3
            },
            1000: {
                items: 4
            }
        },
        nav: false,
        navText: false,
        margin: 30
    });

    $('.date input,.time input.form-control').datepicker({
        autoclose: true,
        format: "dd/mm/yyyy"
    });
 

});

// counter
(function ($) {
    var MIN_COUNT = 0;
    var MAX_COUNT = 10;

    $('[data-counter]').on('click', function (event) {
        var $this = $(this);
        var $target = $(event.target);
        var $targetType = $target.attr('data-count');
        var $counter = $this.find('[data-counter-input]');
        var count = $counter.val();
        var currentCount = count ? parseInt(count) : 0;

        if ($targetType === 'up') {
            incrementCounterUp($counter, currentCount);
        } else if ($targetType === 'down') {
            incrementCounterDown($counter, currentCount);
        } else {
            return false;
        }

        resolveButtonState($this);
    });

    function incrementCounterUp($counter, currentCount) {
        if (currentCount + 1 > MAX_COUNT) {
            return false;
        } else {
            currentCount = currentCount + 1;
            $counter.val(currentCount);
        }
    }

    function incrementCounterDown($counter, currentCount) {
        if (currentCount - 1 < MIN_COUNT) {
            $counter.val(0);
        } else {
            currentCount = currentCount - 1;
            $counter.val(currentCount);
        }
    }

    function resolveButtonState($this) {
        var $upButton = $this.find('[data-count="up"]');
        var $downButton = $this.find('[data-count="down"]');
        var count = $this.find('[data-counter-input]').val();
        var currentCount = count ? parseInt(count) : 0;

        if (currentCount + 1 > MAX_COUNT) {
            $upButton.addClass('disabled');
        } else {
            $upButton.removeClass('disabled');
        }

        if (currentCount - 1 < MIN_COUNT) {
            $downButton.addClass('disabled');
        } else {
            $downButton.removeClass('disabled');
        }
    }
})(jQuery);
function formatState (state) {
    if (!state.id) { return state.text; }
    var $state = $(
      '<span><img src="' + $(state.element).attr('data-src') + '" class="img-flag" /> ' + state.text + '</span>'
    );
    return $state;
  };
  $('.myselect').select2({
    minimumResultsForSearch: Infinity,
    templateResult: formatState,
    templateSelection: formatState
  });

